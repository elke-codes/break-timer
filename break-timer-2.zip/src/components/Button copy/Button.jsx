import React from "react";

const Button = () => {
	return (
		<button
			type="submit"
			//on click ==> display timer form
		>
			Add Timer
		</button>
	);
};

export default Button;
