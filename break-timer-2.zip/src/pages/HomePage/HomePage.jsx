import React from "react";
import { Link } from "react-router-dom";
import Button from "../../components/Button/Button";
import Clock from "../../components/Clock/Clock";
import TimerForm from "../../components/TimerForm/TimerForm";
import { Router } from "react-router-dom";

const HomePage = () => {
	return (
		<>
			<Clock />
			<Link to="/form">
				<button
					type="submit"
					//on click ==> display timer form
				>
					Add Timer
				</button>
			</Link>
		</>
	);
};

export default HomePage;
